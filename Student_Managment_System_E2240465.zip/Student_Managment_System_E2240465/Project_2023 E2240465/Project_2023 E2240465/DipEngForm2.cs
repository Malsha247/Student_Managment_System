﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_2023_E2240465
{
    public partial class DipEngForm2 : Form
    {
        public DipEngForm2()
        {
            InitializeComponent();
        }

        private void btnbackthomp_Click(object sender, EventArgs e)
        {
            Home_Form2 homobj = new Home_Form2();//it to home
            homobj.ShowDialog();
            this.Show();
            DipEngForm2 enobj = new DipEngForm2();
            enobj.ShowDialog();
            this.Hide();
        }
    }
}
