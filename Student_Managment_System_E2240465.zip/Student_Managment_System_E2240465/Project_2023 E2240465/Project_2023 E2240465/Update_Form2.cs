﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_2023_E2240465
{
    public partial class Update_Form2 : Form
    {
        public Update_Form2()
        {
            InitializeComponent();
        }

        private void btnBhome_Click(object sender, EventArgs e)
        {
            Update_Form2 upobj = new Update_Form2();
            upobj.Hide();
            Home_Form2 homobj = new Home_Form2();
            homobj.Show();


        }

        
        
            
            

        
    }
}
