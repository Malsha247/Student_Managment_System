﻿namespace Project_2023_E2240465
{
    partial class PaymentForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtStuName = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.btnUpdatep = new System.Windows.Forms.Button();
            this.btnSavep = new System.Windows.Forms.Button();
            this.btnDeletep = new System.Windows.Forms.Button();
            this.btnbackthomp = new System.Windows.Forms.Button();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial Black", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(30, 96);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(94, 15);
            this.label2.TabIndex = 19;
            this.label2.Text = "1.STUDENT ID";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Black", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(30, 145);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(114, 15);
            this.label1.TabIndex = 20;
            this.label1.Text = "2.PAYMENT TYPE";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial Black", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(30, 194);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(114, 15);
            this.label3.TabIndex = 21;
            this.label3.Text = "3.PAYMENT DATE";
            // 
            // txtStuName
            // 
            this.txtStuName.Location = new System.Drawing.Point(198, 91);
            this.txtStuName.Name = "txtStuName";
            this.txtStuName.Size = new System.Drawing.Size(211, 20);
            this.txtStuName.TabIndex = 27;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(198, 140);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(211, 20);
            this.textBox1.TabIndex = 28;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Bell MT", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(238, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(151, 29);
            this.label4.TabIndex = 30;
            this.label4.Text = "PAYMENTS";
            // 
            // btnUpdatep
            // 
            this.btnUpdatep.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btnUpdatep.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnUpdatep.Location = new System.Drawing.Point(198, 225);
            this.btnUpdatep.Name = "btnUpdatep";
            this.btnUpdatep.Size = new System.Drawing.Size(87, 26);
            this.btnUpdatep.TabIndex = 36;
            this.btnUpdatep.Text = "UPDATE";
            this.btnUpdatep.UseVisualStyleBackColor = false;
            // 
            // btnSavep
            // 
            this.btnSavep.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btnSavep.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnSavep.Location = new System.Drawing.Point(301, 225);
            this.btnSavep.Name = "btnSavep";
            this.btnSavep.Size = new System.Drawing.Size(88, 26);
            this.btnSavep.TabIndex = 37;
            this.btnSavep.Text = "SAVE";
            this.btnSavep.UseVisualStyleBackColor = false;
            // 
            // btnDeletep
            // 
            this.btnDeletep.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btnDeletep.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnDeletep.Location = new System.Drawing.Point(404, 225);
            this.btnDeletep.Name = "btnDeletep";
            this.btnDeletep.Size = new System.Drawing.Size(88, 26);
            this.btnDeletep.TabIndex = 38;
            this.btnDeletep.Text = "DELETE";
            this.btnDeletep.UseVisualStyleBackColor = false;
            // 
            // btnbackthomp
            // 
            this.btnbackthomp.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btnbackthomp.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnbackthomp.Location = new System.Drawing.Point(512, 225);
            this.btnbackthomp.Name = "btnbackthomp";
            this.btnbackthomp.Size = new System.Drawing.Size(110, 26);
            this.btnbackthomp.TabIndex = 39;
            this.btnbackthomp.Text = "BACK TO HOME";
            this.btnbackthomp.UseVisualStyleBackColor = false;
            this.btnbackthomp.Click += new System.EventHandler(this.btnbackthomp_Click);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(198, 194);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(211, 20);
            this.dateTimePicker1.TabIndex = 40;
            // 
            // PaymentForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(765, 283);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.btnbackthomp);
            this.Controls.Add(this.btnDeletep);
            this.Controls.Add(this.btnSavep);
            this.Controls.Add(this.btnUpdatep);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.txtStuName);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "PaymentForm";
            this.Text = "PaymentForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtStuName;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnUpdatep;
        private System.Windows.Forms.Button btnSavep;
        private System.Windows.Forms.Button btnDeletep;
        private System.Windows.Forms.Button btnbackthomp;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
    }
}