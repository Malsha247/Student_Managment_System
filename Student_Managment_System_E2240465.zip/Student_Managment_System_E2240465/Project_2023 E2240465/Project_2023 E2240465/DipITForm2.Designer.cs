﻿namespace Project_2023_E2240465
{
    partial class DipITForm2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnbackthomp = new System.Windows.Forms.Button();
            this.btnDeletep = new System.Windows.Forms.Button();
            this.btnSavep = new System.Windows.Forms.Button();
            this.btnUpdatep = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.txtStuName = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnbackthomp
            // 
            this.btnbackthomp.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btnbackthomp.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnbackthomp.Location = new System.Drawing.Point(511, 306);
            this.btnbackthomp.Name = "btnbackthomp";
            this.btnbackthomp.Size = new System.Drawing.Size(110, 26);
            this.btnbackthomp.TabIndex = 50;
            this.btnbackthomp.Text = "BACK TO HOME";
            this.btnbackthomp.UseVisualStyleBackColor = false;
            this.btnbackthomp.Click += new System.EventHandler(this.btnbackthomp_Click);
            // 
            // btnDeletep
            // 
            this.btnDeletep.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btnDeletep.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnDeletep.Location = new System.Drawing.Point(404, 306);
            this.btnDeletep.Name = "btnDeletep";
            this.btnDeletep.Size = new System.Drawing.Size(88, 26);
            this.btnDeletep.TabIndex = 49;
            this.btnDeletep.Text = "DELETE";
            this.btnDeletep.UseVisualStyleBackColor = false;
            // 
            // btnSavep
            // 
            this.btnSavep.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btnSavep.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnSavep.Location = new System.Drawing.Point(299, 306);
            this.btnSavep.Name = "btnSavep";
            this.btnSavep.Size = new System.Drawing.Size(88, 26);
            this.btnSavep.TabIndex = 48;
            this.btnSavep.Text = "SAVE";
            this.btnSavep.UseVisualStyleBackColor = false;
            this.btnSavep.Click += new System.EventHandler(this.btnSavep_Click);
            // 
            // btnUpdatep
            // 
            this.btnUpdatep.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btnUpdatep.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnUpdatep.Location = new System.Drawing.Point(196, 306);
            this.btnUpdatep.Name = "btnUpdatep";
            this.btnUpdatep.Size = new System.Drawing.Size(87, 26);
            this.btnUpdatep.TabIndex = 47;
            this.btnUpdatep.Text = "UPDATE";
            this.btnUpdatep.UseVisualStyleBackColor = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Bell MT", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(222, 37);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(165, 29);
            this.label4.TabIndex = 46;
            this.label4.Text = "Diploma In IT";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(299, 217);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(175, 20);
            this.textBox2.TabIndex = 45;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(299, 168);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(175, 20);
            this.textBox1.TabIndex = 44;
            // 
            // txtStuName
            // 
            this.txtStuName.Location = new System.Drawing.Point(299, 124);
            this.txtStuName.Name = "txtStuName";
            this.txtStuName.Size = new System.Drawing.Size(175, 20);
            this.txtStuName.TabIndex = 43;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial Black", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(28, 222);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(219, 15);
            this.label3.TabIndex = 42;
            this.label3.Text = "3.Fundamentals and Office Package";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Black", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(28, 173);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(247, 15);
            this.label1.TabIndex = 41;
            this.label1.Text = "2.Programming and Web Designing Mark\r\n";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial Black", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(28, 124);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(94, 15);
            this.label2.TabIndex = 40;
            this.label2.Text = "1.STUDENT ID";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(299, 260);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(175, 20);
            this.textBox3.TabIndex = 52;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial Black", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(28, 265);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 15);
            this.label5.TabIndex = 51;
            this.label5.Text = "4.Grade";
            // 
            // DipITForm2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(667, 344);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.btnbackthomp);
            this.Controls.Add(this.btnDeletep);
            this.Controls.Add(this.btnSavep);
            this.Controls.Add(this.btnUpdatep);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.txtStuName);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "DipITForm2";
            this.Text = "DipITForm2";
            this.Load += new System.EventHandler(this.DipITForm2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnbackthomp;
        private System.Windows.Forms.Button btnDeletep;
        private System.Windows.Forms.Button btnSavep;
        private System.Windows.Forms.Button btnUpdatep;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox txtStuName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label5;
    }
}