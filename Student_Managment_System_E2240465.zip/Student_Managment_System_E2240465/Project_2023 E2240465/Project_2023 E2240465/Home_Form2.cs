﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_2023_E2240465
{
    public partial class Home_Form2 : Form
    {
        public Home_Form2()
        {
            InitializeComponent();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Home_Form2 homobj = new Home_Form2();
            this.Hide();
            Update_Form2 upobj = new Update_Form2();//Update_Form
            upobj.Show();
        }

        private void LinkdlblstReg_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Home_Form2 homobj = new Home_Form2(); 
            this.Hide();
            Student_Registration_Form STRobj = new Student_Registration_Form();//Registration_Form
            STRobj.Show(); 
            
            
            
        }

        private void LinkdlblstGrdsandMrks_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Home_Form2 homobj = new Home_Form2();
            this.Hide();
            Course_MenuForm2 coursobj = new Course_MenuForm2();
            coursobj.Show();
            
        }

        private void LinkdlblstPay_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Home_Form2 homobj = new Home_Form2();
            this.Hide();
            PaymentForm pyobj = new PaymentForm();
            pyobj.Show();
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)//home close
        {
            Application.Exit();
        }
    }
}
