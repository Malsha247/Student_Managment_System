﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_2023_E2240465
{
    public partial class Student_Registration_Form : Form
    {
        public Student_Registration_Form()
        {
            InitializeComponent();
        }

        private void Student_Registration_Form_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'studentDetailsDataSet1._I_E_ST_DETAILS' table. You can move, or remove it, as needed.
            this.i_E_ST_DETAILSTableAdapter.Fill(this.studentDetailsDataSet1._I_E_ST_DETAILS);

        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

        }

        private void txtStuName_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnBhome_Click(object sender, EventArgs e)
        {
           Student_Registration_Form STRobj = new Student_Registration_Form();
           this.Hide();
           Home_Form2 homobj = new Home_Form2();
           homobj.Show();


        }

        private void btnRegister_Click(object sender, EventArgs e)

        {
            
            

            Application_sheet_Form2 app = new Application_sheet_Form2();
            app.Show();

            
            Application_sheet_Form2 appobj = new Application_sheet_Form2();
            appobj.Show();
            this.Show();

            Home_Form2 homobj = new Home_Form2();
            homobj.Show();
            this.Hide();

           

        }
    }
}
