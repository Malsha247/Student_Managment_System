﻿
namespace Project_2023_E2240465
{
    partial class Student_Registration_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txtStuName = new System.Windows.Forms.TextBox();
            this.iESTDETAILSBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.studentDetailsDataSet1 = new Project_2023_E2240465.StudentDetailsDataSet1();
            this.txtStuId = new System.Windows.Forms.TextBox();
            this.txtTpn = new System.Windows.Forms.TextBox();
            this.txtmail = new System.Windows.Forms.TextBox();
            this.txtGender = new System.Windows.Forms.ComboBox();
            this.txtCourse = new System.Windows.Forms.ComboBox();
            this.txtSPayType = new System.Windows.Forms.ComboBox();
            this.btnRegister = new System.Windows.Forms.Button();
            this.btnBhome = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.i_E_ST_DETAILSTableAdapter = new Project_2023_E2240465.StudentDetailsDataSet1TableAdapters.I_E_ST_DETAILSTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.iESTDETAILSBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentDetailsDataSet1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(34)))), ((int)(((byte)(75)))));
            this.panel1.Location = new System.Drawing.Point(-2, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(205, 539);
            this.panel1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Bell MT", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(303, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(311, 29);
            this.label1.TabIndex = 1;
            this.label1.Text = "STUDENT REGISTRAION";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial Black", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(249, 103);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(117, 15);
            this.label2.TabIndex = 2;
            this.label2.Text = "1.STUDENT NAME";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial Black", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(249, 336);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 15);
            this.label3.TabIndex = 3;
            this.label3.Text = "6.COURSE ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial Black", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(260, 321);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 15);
            this.label4.TabIndex = 4;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial Black", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(249, 288);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(56, 15);
            this.label5.TabIndex = 5;
            this.label5.Text = "5.EMAIL";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial Black", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(249, 240);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(150, 15);
            this.label6.TabIndex = 6;
            this.label6.Text = "4.TELEPHONE NUMBER";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial Black", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(249, 194);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(70, 15);
            this.label7.TabIndex = 7;
            this.label7.Text = "3.GENDER";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial Black", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(249, 147);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(94, 15);
            this.label8.TabIndex = 8;
            this.label8.Text = "2.STUDENT ID";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial Black", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(249, 385);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(114, 15);
            this.label9.TabIndex = 9;
            this.label9.Text = "7.PAYMENT TYPE";
            // 
            // txtStuName
            // 
            this.txtStuName.DataBindings.Add(new System.Windows.Forms.Binding("Tag", this.iESTDETAILSBindingSource, "Student_Name", true));
            this.txtStuName.Location = new System.Drawing.Point(486, 101);
            this.txtStuName.Name = "txtStuName";
            this.txtStuName.Size = new System.Drawing.Size(175, 20);
            this.txtStuName.TabIndex = 10;
            this.txtStuName.TextChanged += new System.EventHandler(this.txtStuName_TextChanged);
            // 
            // iESTDETAILSBindingSource
            // 
            this.iESTDETAILSBindingSource.DataMember = "I&E_ST_DETAILS";
            this.iESTDETAILSBindingSource.DataSource = this.studentDetailsDataSet1;
            // 
            // studentDetailsDataSet1
            // 
            this.studentDetailsDataSet1.DataSetName = "StudentDetailsDataSet1";
            this.studentDetailsDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // txtStuId
            // 
            this.txtStuId.DataBindings.Add(new System.Windows.Forms.Binding("Tag", this.iESTDETAILSBindingSource, "Student_ID", true, System.Windows.Forms.DataSourceUpdateMode.OnValidation, null, "N2"));
            this.txtStuId.Location = new System.Drawing.Point(486, 142);
            this.txtStuId.Name = "txtStuId";
            this.txtStuId.Size = new System.Drawing.Size(175, 20);
            this.txtStuId.TabIndex = 11;
            // 
            // txtTpn
            // 
            this.txtTpn.DataBindings.Add(new System.Windows.Forms.Binding("Tag", this.iESTDETAILSBindingSource, "Telephone_Number", true, System.Windows.Forms.DataSourceUpdateMode.OnValidation, null, "N2"));
            this.txtTpn.Location = new System.Drawing.Point(486, 235);
            this.txtTpn.Name = "txtTpn";
            this.txtTpn.Size = new System.Drawing.Size(175, 20);
            this.txtTpn.TabIndex = 12;
            // 
            // txtmail
            // 
            this.txtmail.DataBindings.Add(new System.Windows.Forms.Binding("Tag", this.iESTDETAILSBindingSource, "Email", true));
            this.txtmail.Location = new System.Drawing.Point(486, 283);
            this.txtmail.Name = "txtmail";
            this.txtmail.Size = new System.Drawing.Size(175, 20);
            this.txtmail.TabIndex = 13;
            // 
            // txtGender
            // 
            this.txtGender.DataBindings.Add(new System.Windows.Forms.Binding("Tag", this.iESTDETAILSBindingSource, "Gender", true));
            this.txtGender.FormattingEnabled = true;
            this.txtGender.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.txtGender.Location = new System.Drawing.Point(486, 187);
            this.txtGender.Name = "txtGender";
            this.txtGender.Size = new System.Drawing.Size(175, 21);
            this.txtGender.TabIndex = 14;
            // 
            // txtCourse
            // 
            this.txtCourse.DataBindings.Add(new System.Windows.Forms.Binding("Tag", this.iESTDETAILSBindingSource, "Course", true));
            this.txtCourse.FormattingEnabled = true;
            this.txtCourse.Items.AddRange(new object[] {
            "Diploma in Information Technology",
            "Diploma in English",
            "Dual Diploma"});
            this.txtCourse.Location = new System.Drawing.Point(486, 330);
            this.txtCourse.Name = "txtCourse";
            this.txtCourse.Size = new System.Drawing.Size(175, 21);
            this.txtCourse.TabIndex = 15;
            // 
            // txtSPayType
            // 
            this.txtSPayType.DataBindings.Add(new System.Windows.Forms.Binding("Tag", this.iESTDETAILSBindingSource, "Payment_Type", true));
            this.txtSPayType.FormattingEnabled = true;
            this.txtSPayType.Items.AddRange(new object[] {
            "Full Payment",
            "Half Payment"});
            this.txtSPayType.Location = new System.Drawing.Point(486, 385);
            this.txtSPayType.Name = "txtSPayType";
            this.txtSPayType.Size = new System.Drawing.Size(175, 21);
            this.txtSPayType.TabIndex = 16;
            // 
            // btnRegister
            // 
            this.btnRegister.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btnRegister.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnRegister.Location = new System.Drawing.Point(290, 489);
            this.btnRegister.Name = "btnRegister";
            this.btnRegister.Size = new System.Drawing.Size(124, 30);
            this.btnRegister.TabIndex = 17;
            this.btnRegister.Text = "REGISTER";
            this.btnRegister.UseVisualStyleBackColor = false;
            this.btnRegister.Click += new System.EventHandler(this.btnRegister_Click);
            // 
            // btnBhome
            // 
            this.btnBhome.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnBhome.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnBhome.Location = new System.Drawing.Point(490, 489);
            this.btnBhome.Name = "btnBhome";
            this.btnBhome.Size = new System.Drawing.Size(124, 30);
            this.btnBhome.TabIndex = 18;
            this.btnBhome.Text = "BACK TO HOME";
            this.btnBhome.UseVisualStyleBackColor = false;
            this.btnBhome.Click += new System.EventHandler(this.btnBhome_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Arial Black", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(249, 439);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(114, 15);
            this.label10.TabIndex = 19;
            this.label10.Text = "8.PAYMENT DATE";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.DataBindings.Add(new System.Windows.Forms.Binding("Tag", this.iESTDETAILSBindingSource, "Payment_Date", true));
            this.dateTimePicker1.Location = new System.Drawing.Point(486, 439);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(175, 20);
            this.dateTimePicker1.TabIndex = 20;
            // 
            // i_E_ST_DETAILSTableAdapter
            // 
            this.i_E_ST_DETAILSTableAdapter.ClearBeforeFill = true;
            // 
            // Student_Registration_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(687, 540);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.btnBhome);
            this.Controls.Add(this.btnRegister);
            this.Controls.Add(this.txtSPayType);
            this.Controls.Add(this.txtCourse);
            this.Controls.Add(this.txtGender);
            this.Controls.Add(this.txtmail);
            this.Controls.Add(this.txtTpn);
            this.Controls.Add(this.txtStuId);
            this.Controls.Add(this.txtStuName);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Student_Registration_Form";
            this.Load += new System.EventHandler(this.Student_Registration_Form_Load);
            ((System.ComponentModel.ISupportInitialize)(this.iESTDETAILSBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentDetailsDataSet1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btnRegister;
        private System.Windows.Forms.Button btnBhome;
        private System.Windows.Forms.Label label10;
        private StudentDetailsDataSet1 studentDetailsDataSet1;
        private System.Windows.Forms.BindingSource iESTDETAILSBindingSource;
        private StudentDetailsDataSet1TableAdapters.I_E_ST_DETAILSTableAdapter i_E_ST_DETAILSTableAdapter;
        public System.Windows.Forms.TextBox txtStuName;
        public System.Windows.Forms.TextBox txtStuId;
        public System.Windows.Forms.TextBox txtTpn;
        public System.Windows.Forms.TextBox txtmail;
        public System.Windows.Forms.ComboBox txtGender;
        public System.Windows.Forms.ComboBox txtCourse;
        public System.Windows.Forms.ComboBox txtSPayType;
        public System.Windows.Forms.DateTimePicker dateTimePicker1;
    }
}