﻿
using System;

namespace Project_2023_E2240465
{
    partial class Update_Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.txtSPayType = new System.Windows.Forms.ComboBox();
            this.txtCourse = new System.Windows.Forms.ComboBox();
            this.txtGender = new System.Windows.Forms.ComboBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.txtStuId = new System.Windows.Forms.TextBox();
            this.txtStuName = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.btnBhome = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.student_DataSet = new Project_2023_E2240465.Student_DataSet();
            this.studentDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.studentDataSetBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.studentDataSetBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.studentDetailsDataSet1 = new Project_2023_E2240465.StudentDetailsDataSet1();
            this.iESTDETAILSBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.i_E_ST_DETAILSTableAdapter = new Project_2023_E2240465.StudentDetailsDataSet1TableAdapters.I_E_ST_DETAILSTableAdapter();
            this.studentIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.studentNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.genderDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.telephoneNumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.emailDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.courseDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.paymentTypeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.paymentDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grammerandWritngDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.spokenDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.programmingandWebDesigningMarksDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fundamentalsandOfficePackageMarksDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gradeofITDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gradeofEnglishDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.student_DataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentDataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentDataSetBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentDataSetBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentDetailsDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iESTDETAILSBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // txtSPayType
            // 
            this.txtSPayType.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.iESTDETAILSBindingSource, "Payment_Type", true));
            this.txtSPayType.FormattingEnabled = true;
            this.txtSPayType.Location = new System.Drawing.Point(229, 397);
            this.txtSPayType.Name = "txtSPayType";
            this.txtSPayType.Size = new System.Drawing.Size(175, 21);
            this.txtSPayType.TabIndex = 32;
            // 
            // txtCourse
            // 
            this.txtCourse.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.iESTDETAILSBindingSource, "Course", true));
            this.txtCourse.FormattingEnabled = true;
            this.txtCourse.Location = new System.Drawing.Point(229, 342);
            this.txtCourse.Name = "txtCourse";
            this.txtCourse.Size = new System.Drawing.Size(175, 21);
            this.txtCourse.TabIndex = 31;
            // 
            // txtGender
            // 
            this.txtGender.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.iESTDETAILSBindingSource, "Gender", true));
            this.txtGender.FormattingEnabled = true;
            this.txtGender.Location = new System.Drawing.Point(229, 199);
            this.txtGender.Name = "txtGender";
            this.txtGender.Size = new System.Drawing.Size(175, 21);
            this.txtGender.TabIndex = 30;
            // 
            // textBox4
            // 
            this.textBox4.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.iESTDETAILSBindingSource, "Email", true));
            this.textBox4.Location = new System.Drawing.Point(229, 295);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(175, 20);
            this.textBox4.TabIndex = 29;
            // 
            // textBox3
            // 
            this.textBox3.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.iESTDETAILSBindingSource, "Telephone_Number", true));
            this.textBox3.Location = new System.Drawing.Point(229, 247);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(175, 20);
            this.textBox3.TabIndex = 28;
            // 
            // txtStuId
            // 
            this.txtStuId.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.iESTDETAILSBindingSource, "Student_ID", true));
            this.txtStuId.Location = new System.Drawing.Point(229, 154);
            this.txtStuId.Name = "txtStuId";
            this.txtStuId.Size = new System.Drawing.Size(175, 20);
            this.txtStuId.TabIndex = 27;
            // 
            // txtStuName
            // 
            this.txtStuName.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.iESTDETAILSBindingSource, "Student_Name", true));
            this.txtStuName.Location = new System.Drawing.Point(229, 113);
            this.txtStuName.Name = "txtStuName";
            this.txtStuName.Size = new System.Drawing.Size(175, 20);
            this.txtStuName.TabIndex = 26;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial Black", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(26, 397);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(114, 15);
            this.label9.TabIndex = 25;
            this.label9.Text = "7.PAYMENT TYPE";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial Black", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(26, 159);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(94, 15);
            this.label8.TabIndex = 24;
            this.label8.Text = "2.STUDENT ID";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial Black", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(26, 206);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(70, 15);
            this.label7.TabIndex = 23;
            this.label7.Text = "3.GENDER";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial Black", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(26, 252);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(150, 15);
            this.label6.TabIndex = 22;
            this.label6.Text = "4.TELEPHONE NUMBER";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial Black", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(26, 300);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(56, 15);
            this.label5.TabIndex = 21;
            this.label5.Text = "5.EMAIL";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial Black", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(37, 333);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 15);
            this.label4.TabIndex = 20;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial Black", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(26, 348);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 15);
            this.label3.TabIndex = 19;
            this.label3.Text = "6.COURSE ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial Black", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(26, 115);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(117, 15);
            this.label2.TabIndex = 18;
            this.label2.Text = "1.STUDENT NAME";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Bell MT", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(319, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(230, 29);
            this.label1.TabIndex = 17;
            this.label1.Text = "UPDATE DETAILS";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.button1.Location = new System.Drawing.Point(484, 387);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(104, 34);
            this.button1.TabIndex = 34;
            this.button1.Text = "SAVE";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.button2.Location = new System.Drawing.Point(626, 389);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(104, 34);
            this.button2.TabIndex = 35;
            this.button2.Text = "UPDATE";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.button3.Location = new System.Drawing.Point(761, 389);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(104, 34);
            this.button3.TabIndex = 36;
            this.button3.Text = "DELETE";
            this.button3.UseVisualStyleBackColor = false;
            // 
            // btnBhome
            // 
            this.btnBhome.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnBhome.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnBhome.Location = new System.Drawing.Point(895, 391);
            this.btnBhome.Name = "btnBhome";
            this.btnBhome.Size = new System.Drawing.Size(124, 30);
            this.btnBhome.TabIndex = 37;
            this.btnBhome.Text = "BACK TO HOME";
            this.btnBhome.UseVisualStyleBackColor = false;
            this.btnBhome.Click += new System.EventHandler(this.btnBhome_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToOrderColumns = true;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.studentIDDataGridViewTextBoxColumn,
            this.studentNameDataGridViewTextBoxColumn,
            this.genderDataGridViewTextBoxColumn,
            this.telephoneNumberDataGridViewTextBoxColumn,
            this.emailDataGridViewTextBoxColumn,
            this.courseDataGridViewTextBoxColumn,
            this.paymentTypeDataGridViewTextBoxColumn,
            this.paymentDateDataGridViewTextBoxColumn,
            this.grammerandWritngDataGridViewTextBoxColumn,
            this.spokenDataGridViewTextBoxColumn,
            this.programmingandWebDesigningMarksDataGridViewTextBoxColumn,
            this.fundamentalsandOfficePackageMarksDataGridViewTextBoxColumn,
            this.gradeofITDataGridViewTextBoxColumn,
            this.gradeofEnglishDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.iESTDETAILSBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(445, 113);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(574, 257);
            this.dataGridView1.TabIndex = 38;
            // 
            // student_DataSet
            // 
            this.student_DataSet.DataSetName = "Student_DataSet";
            this.student_DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // studentDataSetBindingSource
            // 
            this.studentDataSetBindingSource.DataSource = this.student_DataSet;
            this.studentDataSetBindingSource.Position = 0;
            // 
            // studentDataSetBindingSource1
            // 
            this.studentDataSetBindingSource1.DataSource = this.student_DataSet;
            this.studentDataSetBindingSource1.Position = 0;
            // 
            // studentDataSetBindingSource2
            // 
            this.studentDataSetBindingSource2.DataSource = this.student_DataSet;
            this.studentDataSetBindingSource2.Position = 0;
            // 
            // studentDetailsDataSet1
            // 
            this.studentDetailsDataSet1.DataSetName = "StudentDetailsDataSet1";
            this.studentDetailsDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // iESTDETAILSBindingSource
            // 
            this.iESTDETAILSBindingSource.DataMember = "I&E_ST_DETAILS";
            this.iESTDETAILSBindingSource.DataSource = this.studentDetailsDataSet1;
            // 
            // i_E_ST_DETAILSTableAdapter
            // 
            this.i_E_ST_DETAILSTableAdapter.ClearBeforeFill = true;
            // 
            // studentIDDataGridViewTextBoxColumn
            // 
            this.studentIDDataGridViewTextBoxColumn.DataPropertyName = "Student_ID";
            this.studentIDDataGridViewTextBoxColumn.HeaderText = "Student_ID";
            this.studentIDDataGridViewTextBoxColumn.Name = "studentIDDataGridViewTextBoxColumn";
            // 
            // studentNameDataGridViewTextBoxColumn
            // 
            this.studentNameDataGridViewTextBoxColumn.DataPropertyName = "Student_Name";
            this.studentNameDataGridViewTextBoxColumn.HeaderText = "Student_Name";
            this.studentNameDataGridViewTextBoxColumn.Name = "studentNameDataGridViewTextBoxColumn";
            // 
            // genderDataGridViewTextBoxColumn
            // 
            this.genderDataGridViewTextBoxColumn.DataPropertyName = "Gender";
            this.genderDataGridViewTextBoxColumn.HeaderText = "Gender";
            this.genderDataGridViewTextBoxColumn.Name = "genderDataGridViewTextBoxColumn";
            // 
            // telephoneNumberDataGridViewTextBoxColumn
            // 
            this.telephoneNumberDataGridViewTextBoxColumn.DataPropertyName = "Telephone_Number";
            this.telephoneNumberDataGridViewTextBoxColumn.HeaderText = "Telephone_Number";
            this.telephoneNumberDataGridViewTextBoxColumn.Name = "telephoneNumberDataGridViewTextBoxColumn";
            // 
            // emailDataGridViewTextBoxColumn
            // 
            this.emailDataGridViewTextBoxColumn.DataPropertyName = "Email";
            this.emailDataGridViewTextBoxColumn.HeaderText = "Email";
            this.emailDataGridViewTextBoxColumn.Name = "emailDataGridViewTextBoxColumn";
            // 
            // courseDataGridViewTextBoxColumn
            // 
            this.courseDataGridViewTextBoxColumn.DataPropertyName = "Course";
            this.courseDataGridViewTextBoxColumn.HeaderText = "Course";
            this.courseDataGridViewTextBoxColumn.Name = "courseDataGridViewTextBoxColumn";
            // 
            // paymentTypeDataGridViewTextBoxColumn
            // 
            this.paymentTypeDataGridViewTextBoxColumn.DataPropertyName = "Payment_Type";
            this.paymentTypeDataGridViewTextBoxColumn.HeaderText = "Payment_Type";
            this.paymentTypeDataGridViewTextBoxColumn.Name = "paymentTypeDataGridViewTextBoxColumn";
            // 
            // paymentDateDataGridViewTextBoxColumn
            // 
            this.paymentDateDataGridViewTextBoxColumn.DataPropertyName = "Payment_Date";
            this.paymentDateDataGridViewTextBoxColumn.HeaderText = "Payment_Date";
            this.paymentDateDataGridViewTextBoxColumn.Name = "paymentDateDataGridViewTextBoxColumn";
            // 
            // grammerandWritngDataGridViewTextBoxColumn
            // 
            this.grammerandWritngDataGridViewTextBoxColumn.DataPropertyName = "Grammer_and_Writng";
            this.grammerandWritngDataGridViewTextBoxColumn.HeaderText = "Grammer_and_Writng";
            this.grammerandWritngDataGridViewTextBoxColumn.Name = "grammerandWritngDataGridViewTextBoxColumn";
            // 
            // spokenDataGridViewTextBoxColumn
            // 
            this.spokenDataGridViewTextBoxColumn.DataPropertyName = "Spoken";
            this.spokenDataGridViewTextBoxColumn.HeaderText = "Spoken";
            this.spokenDataGridViewTextBoxColumn.Name = "spokenDataGridViewTextBoxColumn";
            // 
            // programmingandWebDesigningMarksDataGridViewTextBoxColumn
            // 
            this.programmingandWebDesigningMarksDataGridViewTextBoxColumn.DataPropertyName = "Programming_and_Web_Designing_Marks";
            this.programmingandWebDesigningMarksDataGridViewTextBoxColumn.HeaderText = "Programming_and_Web_Designing_Marks";
            this.programmingandWebDesigningMarksDataGridViewTextBoxColumn.Name = "programmingandWebDesigningMarksDataGridViewTextBoxColumn";
            // 
            // fundamentalsandOfficePackageMarksDataGridViewTextBoxColumn
            // 
            this.fundamentalsandOfficePackageMarksDataGridViewTextBoxColumn.DataPropertyName = "Fundamentals_and_Office_Package_Marks";
            this.fundamentalsandOfficePackageMarksDataGridViewTextBoxColumn.HeaderText = "Fundamentals_and_Office_Package_Marks";
            this.fundamentalsandOfficePackageMarksDataGridViewTextBoxColumn.Name = "fundamentalsandOfficePackageMarksDataGridViewTextBoxColumn";
            // 
            // gradeofITDataGridViewTextBoxColumn
            // 
            this.gradeofITDataGridViewTextBoxColumn.DataPropertyName = "Grade_of_IT";
            this.gradeofITDataGridViewTextBoxColumn.HeaderText = "Grade_of_IT";
            this.gradeofITDataGridViewTextBoxColumn.Name = "gradeofITDataGridViewTextBoxColumn";
            // 
            // gradeofEnglishDataGridViewTextBoxColumn
            // 
            this.gradeofEnglishDataGridViewTextBoxColumn.DataPropertyName = "Grade_of_English";
            this.gradeofEnglishDataGridViewTextBoxColumn.HeaderText = "Grade_of_English";
            this.gradeofEnglishDataGridViewTextBoxColumn.Name = "gradeofEnglishDataGridViewTextBoxColumn";
            // 
            // Update_Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1044, 450);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.btnBhome);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.txtSPayType);
            this.Controls.Add(this.txtCourse);
            this.Controls.Add(this.txtGender);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.txtStuId);
            this.Controls.Add(this.txtStuName);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Update_Form2";
            this.Text = "Update_Form2";
            this.Load += new System.EventHandler(this.Update_Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.student_DataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentDataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentDataSetBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentDataSetBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentDetailsDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iESTDETAILSBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox txtSPayType;
        private System.Windows.Forms.ComboBox txtCourse;
        private System.Windows.Forms.ComboBox txtGender;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox txtStuId;
        private System.Windows.Forms.TextBox txtStuName;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button btnBhome;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.BindingSource studentDataSetBindingSource2;
        private Student_DataSet student_DataSet;
        private System.Windows.Forms.BindingSource studentDataSetBindingSource;
        private System.Windows.Forms.BindingSource studentDataSetBindingSource1;
        private StudentDetailsDataSet1 studentDetailsDataSet1;
        private System.Windows.Forms.BindingSource iESTDETAILSBindingSource;
        private StudentDetailsDataSet1TableAdapters.I_E_ST_DETAILSTableAdapter i_E_ST_DETAILSTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn studentIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn studentNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn genderDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn telephoneNumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn emailDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn courseDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn paymentTypeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn paymentDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn grammerandWritngDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn spokenDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn programmingandWebDesigningMarksDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn fundamentalsandOfficePackageMarksDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn gradeofITDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn gradeofEnglishDataGridViewTextBoxColumn;

        public EventHandler Update_Form2_Load { get; private set; }
    }
}