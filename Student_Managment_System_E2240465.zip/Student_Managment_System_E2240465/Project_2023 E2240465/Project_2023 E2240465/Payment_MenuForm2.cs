﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_2023_E2240465
{
    public partial class Payment_MenuForm2 : Form
    {
        public Payment_MenuForm2()
        {
            InitializeComponent();
        }
    }
}
