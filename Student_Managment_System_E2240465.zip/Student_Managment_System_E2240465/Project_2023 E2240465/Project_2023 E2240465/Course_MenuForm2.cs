﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_2023_E2240465
{
    public partial class Course_MenuForm2 : Form
    {
        public Course_MenuForm2()
        {
            InitializeComponent();
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Home_Form2 homobj = new Home_Form2();// course to home
            this.Show();
            Course_MenuForm2 crsobj = new Course_MenuForm2();
            this.Hide();

        }
    }
}
