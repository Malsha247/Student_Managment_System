﻿namespace Project_2023_E2240465
{
    partial class Course_MenuForm2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LinkdlblstGrdsandMrks = new System.Windows.Forms.LinkLabel();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.label4 = new System.Windows.Forms.Label();
            this.linkLabelHmClose = new System.Windows.Forms.LinkLabel();
            this.linkLabel2 = new System.Windows.Forms.LinkLabel();
            this.SuspendLayout();
            // 
            // LinkdlblstGrdsandMrks
            // 
            this.LinkdlblstGrdsandMrks.AutoSize = true;
            this.LinkdlblstGrdsandMrks.Font = new System.Drawing.Font("Palatino Linotype", 18F, System.Drawing.FontStyle.Bold);
            this.LinkdlblstGrdsandMrks.LinkColor = System.Drawing.Color.White;
            this.LinkdlblstGrdsandMrks.Location = new System.Drawing.Point(50, 144);
            this.LinkdlblstGrdsandMrks.Name = "LinkdlblstGrdsandMrks";
            this.LinkdlblstGrdsandMrks.Size = new System.Drawing.Size(114, 32);
            this.LinkdlblstGrdsandMrks.TabIndex = 4;
            this.LinkdlblstGrdsandMrks.TabStop = true;
            this.LinkdlblstGrdsandMrks.Text = "Dip in IT\r\n";
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Font = new System.Drawing.Font("Palatino Linotype", 18F, System.Drawing.FontStyle.Bold);
            this.linkLabel1.LinkColor = System.Drawing.Color.White;
            this.linkLabel1.Location = new System.Drawing.Point(243, 144);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(172, 32);
            this.linkLabel1.TabIndex = 5;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "Dip in English";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Bell MT", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label4.Location = new System.Drawing.Point(165, 23);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(124, 29);
            this.label4.TabIndex = 31;
            this.label4.Text = "COURSES";
            // 
            // linkLabelHmClose
            // 
            this.linkLabelHmClose.AutoSize = true;
            this.linkLabelHmClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabelHmClose.LinkColor = System.Drawing.Color.Red;
            this.linkLabelHmClose.Location = new System.Drawing.Point(393, 9);
            this.linkLabelHmClose.Name = "linkLabelHmClose";
            this.linkLabelHmClose.Size = new System.Drawing.Size(32, 31);
            this.linkLabelHmClose.TabIndex = 32;
            this.linkLabelHmClose.TabStop = true;
            this.linkLabelHmClose.Text = "X";
            // 
            // linkLabel2
            // 
            this.linkLabel2.AutoSize = true;
            this.linkLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabel2.LinkColor = System.Drawing.Color.Lime;
            this.linkLabel2.Location = new System.Drawing.Point(345, 251);
            this.linkLabel2.Name = "linkLabel2";
            this.linkLabel2.Size = new System.Drawing.Size(100, 16);
            this.linkLabel2.TabIndex = 33;
            this.linkLabel2.TabStop = true;
            this.linkLabel2.Text = "Backto Home";
            this.linkLabel2.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel2_LinkClicked);
            // 
            // Course_MenuForm2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(34)))), ((int)(((byte)(75)))));
            this.ClientSize = new System.Drawing.Size(437, 276);
            this.Controls.Add(this.linkLabel2);
            this.Controls.Add(this.linkLabelHmClose);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.linkLabel1);
            this.Controls.Add(this.LinkdlblstGrdsandMrks);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Course_MenuForm2";
            this.Text = "Course_MenuForm2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.LinkLabel LinkdlblstGrdsandMrks;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.LinkLabel linkLabelHmClose;
        private System.Windows.Forms.LinkLabel linkLabel2;
    }
}