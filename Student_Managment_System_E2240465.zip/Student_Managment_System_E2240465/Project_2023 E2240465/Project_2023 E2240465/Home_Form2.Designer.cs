﻿
namespace Project_2023_E2240465
{
    partial class Home_Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.LinkdlblstReg = new System.Windows.Forms.LinkLabel();
            this.LinkdlblstPay = new System.Windows.Forms.LinkLabel();
            this.LinkdlblstGrdsandMrks = new System.Windows.Forms.LinkLabel();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.linkLabelHmClose = new System.Windows.Forms.LinkLabel();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Bell MT", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label1.Location = new System.Drawing.Point(327, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(135, 42);
            this.label1.TabIndex = 0;
            this.label1.Text = "HOME";
            // 
            // LinkdlblstReg
            // 
            this.LinkdlblstReg.AutoSize = true;
            this.LinkdlblstReg.Font = new System.Drawing.Font("Palatino Linotype", 18F, System.Drawing.FontStyle.Bold);
            this.LinkdlblstReg.LinkColor = System.Drawing.Color.White;
            this.LinkdlblstReg.Location = new System.Drawing.Point(36, 208);
            this.LinkdlblstReg.Name = "LinkdlblstReg";
            this.LinkdlblstReg.Size = new System.Drawing.Size(146, 64);
            this.LinkdlblstReg.TabIndex = 1;
            this.LinkdlblstReg.TabStop = true;
            this.LinkdlblstReg.Text = "Student\r\nRegistration";
            this.LinkdlblstReg.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LinkdlblstReg_LinkClicked);
            // 
            // LinkdlblstPay
            // 
            this.LinkdlblstPay.AutoSize = true;
            this.LinkdlblstPay.Font = new System.Drawing.Font("Palatino Linotype", 18F, System.Drawing.FontStyle.Bold);
            this.LinkdlblstPay.LinkColor = System.Drawing.Color.White;
            this.LinkdlblstPay.Location = new System.Drawing.Point(648, 208);
            this.LinkdlblstPay.Name = "LinkdlblstPay";
            this.LinkdlblstPay.Size = new System.Drawing.Size(115, 64);
            this.LinkdlblstPay.TabIndex = 2;
            this.LinkdlblstPay.TabStop = true;
            this.LinkdlblstPay.Text = "Payment \r\nDetails";
            this.LinkdlblstPay.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LinkdlblstPay_LinkClicked);
            // 
            // LinkdlblstGrdsandMrks
            // 
            this.LinkdlblstGrdsandMrks.AutoSize = true;
            this.LinkdlblstGrdsandMrks.Font = new System.Drawing.Font("Palatino Linotype", 18F, System.Drawing.FontStyle.Bold);
            this.LinkdlblstGrdsandMrks.LinkColor = System.Drawing.Color.White;
            this.LinkdlblstGrdsandMrks.Location = new System.Drawing.Point(443, 208);
            this.LinkdlblstGrdsandMrks.Name = "LinkdlblstGrdsandMrks";
            this.LinkdlblstGrdsandMrks.Size = new System.Drawing.Size(138, 64);
            this.LinkdlblstGrdsandMrks.TabIndex = 3;
            this.LinkdlblstGrdsandMrks.TabStop = true;
            this.LinkdlblstGrdsandMrks.Text = "Marks and \r\nGrades";
            this.LinkdlblstGrdsandMrks.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LinkdlblstGrdsandMrks_LinkClicked);
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Font = new System.Drawing.Font("Palatino Linotype", 18F, System.Drawing.FontStyle.Bold);
            this.linkLabel1.LinkColor = System.Drawing.Color.White;
            this.linkLabel1.Location = new System.Drawing.Point(264, 208);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(93, 64);
            this.linkLabel1.TabIndex = 5;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "Update\r\nDetails";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // linkLabelHmClose
            // 
            this.linkLabelHmClose.AutoSize = true;
            this.linkLabelHmClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabelHmClose.LinkColor = System.Drawing.Color.Red;
            this.linkLabelHmClose.Location = new System.Drawing.Point(743, 9);
            this.linkLabelHmClose.Name = "linkLabelHmClose";
            this.linkLabelHmClose.Size = new System.Drawing.Size(32, 31);
            this.linkLabelHmClose.TabIndex = 6;
            this.linkLabelHmClose.TabStop = true;
            this.linkLabelHmClose.Text = "X";
            this.linkLabelHmClose.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel2_LinkClicked);
            // 
            // Home_Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(34)))), ((int)(((byte)(75)))));
            this.ClientSize = new System.Drawing.Size(787, 306);
            this.Controls.Add(this.linkLabelHmClose);
            this.Controls.Add(this.linkLabel1);
            this.Controls.Add(this.LinkdlblstGrdsandMrks);
            this.Controls.Add(this.LinkdlblstPay);
            this.Controls.Add(this.LinkdlblstReg);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Home_Form2";
            this.Text = "Home_Form2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.LinkLabel LinkdlblstReg;
        private System.Windows.Forms.LinkLabel LinkdlblstPay;
        private System.Windows.Forms.LinkLabel LinkdlblstGrdsandMrks;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.LinkLabel linkLabelHmClose;
    }
}