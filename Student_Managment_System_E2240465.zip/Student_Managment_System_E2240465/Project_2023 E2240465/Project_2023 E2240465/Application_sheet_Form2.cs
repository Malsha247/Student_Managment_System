﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_2023_E2240465
{
    public partial class Application_sheet_Form2 : Form
    {
        Student_Registration_Form reg;
        public Application_sheet_Form2(Student_Registration_Form reg)
        {
            InitializeComponent();
            this.reg = reg;
        }

        public Application_sheet_Form2()
        {
        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void Application_sheet_Form2_Load(object sender, EventArgs e)
        {
          
        }

        private void button1_Click(object sender, EventArgs e)
        {
            

            
        }
    }
}
