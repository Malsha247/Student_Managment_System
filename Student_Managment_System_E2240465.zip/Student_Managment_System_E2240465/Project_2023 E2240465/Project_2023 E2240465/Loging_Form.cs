﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_2023_E2240465
{
    public partial class Loging_Form : Form
    {
        public Loging_Form()
        {
            InitializeComponent();
        }

        private void Loging_Form_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string email = txtEmail.Text;//loging button
            string pass = txtPassword.Text;

            if(email == "admin@IE.lk" && pass == "admin@123")
            {
                MessageBox.Show("Login Success");
                this.Hide();
                Home_Form2 homobj = new Home_Form2();
                homobj.Show();//loging button

            }
            else
            {
                MessageBox.Show("User Name or Password Incorrect");
            }
        }

        private void btnExite_Click(object sender, EventArgs e)
        {
            Application.Exit();//Exite
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
